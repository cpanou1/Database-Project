package jdbcUtil;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

public class StandardInputRead {
		public final static int POS_ERROR = -1;
		
		public final static int NEG_ERROR = 1;
		
		BufferedReader in;
		
		public StandardInputRead() {
			super();
			in = new BufferedReader(new InputStreamReader(System.in));		
		}

		public String readString(String message) {
			
			System.out.print(message);
			try {
				return in.readLine();
			}
			catch (IOException e) {
				return null;
			}			
		}
		
		
		public int readPositiveInt(String message) {
			
			String str;
			int num;
			
			System.out.print(message);			
			try {
				str = in.readLine();
				num = Integer.parseInt(str);
				if (num < 0 ){
					return POS_ERROR;
				}
				else {
					return num;
				}			
			}
			catch (IOException e) {			
				return POS_ERROR;
			}
			catch (NumberFormatException e1) {			
				return POS_ERROR;
			}
		}
		
		
		public int readNegativeInt(String message) {
			
			String str;
			int num;
			
			System.out.print(message);			
			try {
				str = in.readLine();
				num = Integer.parseInt(str);
				if (num >= 0 ){
					return NEG_ERROR;
				}
				else {
					return num;
				}			
			}
			catch (IOException e) {			
				return NEG_ERROR;
			}
			catch (NumberFormatException e1) {			
				return NEG_ERROR;
			}
		}

		
		public float readPositiveFloat(String message) {
			
			String str;
			float num;
			
			System.out.print(message);			
			try {
				str = in.readLine();
				num = Float.parseFloat(str);
				if (num < 0 ){
					return POS_ERROR;
				}
				else {
					return num;
				}			
			}
			catch (IOException e) {			
				return POS_ERROR;
			}
			catch (NumberFormatException e1) {			
				return POS_ERROR;
			}
		}
		
	
		public float readNegativeFloat(String message) {
			
			String str;
			float num;
			
			System.out.print(message);			
			try {
				str = in.readLine();
				num = Float.parseFloat(str);
				if (num >= 0 ){
					return NEG_ERROR;
				}
				else {
					return num;
				}			
			}
			catch (IOException e) {			
				return NEG_ERROR;
			}
			catch (NumberFormatException e1) {			
				return NEG_ERROR;
			}
		}
			
	
		public Date readDate(String message) {
			
			String str;
			
			System.out.print(message);
			
			try {
				str = in.readLine();
				Locale l = new Locale("el", "GR");
				DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, l);
				return df.parse(str);
			}
			catch (IOException e) {
				return null;
			}
			catch (ParseException e1) {
				return null;
			}
		}
		
		
		public Date readTime(String message) {
			
			String str;
			
			System.out.print(message);
			
			try {
				str = in.readLine();		
				DateFormat df = DateFormat.getTimeInstance(DateFormat.SHORT);
				
				return df.parse(str);
			}
			catch (IOException e) {
				return null;
			}
			catch (ParseException e1) {
				return null;
			}
		}

}
