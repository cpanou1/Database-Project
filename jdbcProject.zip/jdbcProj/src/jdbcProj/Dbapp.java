package jdbcProj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.ArrayList;
import jdbcUtil.StandardInputRead;

public class Dbapp {
	private Connection conn;

	public Dbapp() {
		try {
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver Found!");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver Not Found!");

		}
	}
	
	public void startTransaction() {
		try {
			conn.setAutoCommit(false); //an to kanoyme false tha elegxw egw pote kanw syndiallagh kai pote oxi
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	}
	
	public void commit() {
		try {
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void abort() {
		try {
			conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void DbConnect(String ip, String user, String password) {
		try {
			conn = DriverManager.getConnection(ip, user, password);
			System.out.println("Connected!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void DbClose() {
		try {
			conn.close();
			System.out.println("Closing the server!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		Dbapp db = new Dbapp();
		int choice = 0;
		StandardInputRead reader = new StandardInputRead();
		
		while(choice!=6) {
			choice = db.appearMenu();
			switch (choice) {
			  case 1:
		        String ipAddress = reader.readString("Give IP address: ");
		        String name = reader.readString("Give name: ");
		        String userID = reader.readString("Give user name: ");
		        String password = reader.readString("Give password: ");
		        String ip = "jdbc:postgresql://localhost:" + ipAddress + "/" + name;
				db.DbConnect(ip, userID, password);
				db.startTransaction();
			    break;
			  case 2:
				db.commit();
				db.startTransaction();
			    break;
			  case 3:
				db.abort();
				db.startTransaction();
				break;
			  case 4:
			    String course = reader.readString("Give course code: ");
		        int acYear = reader.readPositiveInt("Give academic year: ");
		        String acSeason = reader.readString("Give academic season: ");
			    db.showRegisteredStudents(acYear, acSeason, course);
			    break;
			  case 5:
				String amka = reader.readString("Give amka: ");
		        int acaYear = reader.readPositiveInt("Give academic year: ");
		        String acaSeason = reader.readString("Give academic season: ");
			    db.showGrade(acaYear, acaSeason, amka);
			    break;
			  case 6:
				db.DbClose();
				break;
			  default:
				System.out.println("Wrong number, try again.");
				continue;
			}
		}
	}

	public int appearMenu() {
		System.out.println("1.Insert data to enter database.");
		System.out.println("2.Commit transaction/Create new.");
		System.out.println("3.Abort transaction/Create new.");
		System.out.println("4.Show enrolled students in a certain course.");
		System.out.println("5.Show student's grade.");
		System.out.println("6.Exit database.");
		
		StandardInputRead reader = new StandardInputRead();
        String userInput = reader.readString("Choose between these choices.");
        int userOption = 0;
        userOption = Integer.parseInt(userInput);
		return userOption;
	}
	
	public void showRegisteredStudents(int acYear, String acSeason, String courseCode) {
		try {
			Statement st = conn.createStatement();
			ResultSet res = st.executeQuery("SELECT R.amka, S.name, S.surname FROM \"Register\" R NATURAL JOIN \"Student\" S WHERE R.course_code='"+courseCode+"' AND R.register_status<>'rejected' AND R.serial_number IN (SELECT semester_id FROM \"Semester\" WHERE academic_year="+acYear+" AND academic_season ='"+acSeason+"');");
			
			while(res.next()) {
				System.out.println("amka= " +res.getString(1)+ " name= " +res.getString(2)+ " surname= " +res.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void showGrade(int acYear, String acSeason, String amka) {
		try {
			Statement st = conn.createStatement();
			ResultSet res = st.executeQuery("SELECT row_number() over (order by (select NULL)) as incr_number, course_code, course_title, lab_grade, final_grade FROM (SELECT R.course_code, C.course_title, R.lab_grade, R.final_grade FROM \"Register\" R NATURAL JOIN \"Course\" C WHERE R.amka='"+amka+"' AND (R.register_status<>'rejected' AND R.register_status<>'proposed') AND R.serial_number IN (SELECT semester_id FROM \"Semester\" WHERE academic_year="+acYear+" AND academic_season ='"+acSeason+"') ORDER BY R.course_code) finAr;");
			ArrayList<Integer> incrNumber = new ArrayList<Integer>();
			ArrayList<String> courses = new ArrayList<String>();
			while(res.next()) { 
				System.out.println("number= " +res.getInt(1)+ " courseCode= " +res.getString(2)+ " courseTitle= " +res.getString(3)+ " labGrade= " +res.getInt(4)+ " finalGrade= " +res.getInt(5));
				incrNumber.add(res.getInt(1));
				courses.add(res.getString(2));
			}

			Savepoint inBsvp = conn.setSavepoint();
			ArrayList<Savepoint> arraysvp = new ArrayList<Savepoint>();
			StandardInputRead reader = new StandardInputRead();
			int chNumber = 1;
			int counter = 0;
			while(chNumber!=0) {
				chNumber = reader.readPositiveInt("Choose number from above:");
				switch(chNumber) {
					case 0:
						break;
					case -1:
				        if(counter==0 || arraysvp.isEmpty()) {
				        	System.out.println("No more transaction to delete.");
				        	break;
				        }
				        conn.rollback(arraysvp.get(counter-1));
				        System.out.println(counter);
				        arraysvp.remove(counter-1);
						counter--;
				        break;
					default:
						if(incrNumber.contains(chNumber)) {
							int idx = incrNumber.indexOf(chNumber);
							int finGrade = reader.readPositiveInt("Give final grade: ");
							int labGrade = reader.readPositiveInt("Give lab grade: ");
							PreparedStatement pst = conn.prepareStatement("UPDATE \"Register\" SET final_grade="+finGrade+" , lab_grade="+labGrade+" WHERE amka="+amka+" and course_code='"+courses.get(idx)+"' AND serial_number IN (SELECT semester_id FROM \"Semester\" WHERE academic_year="+acYear+" AND academic_season ='"+acSeason+"');");
							inBsvp = conn.setSavepoint();
							arraysvp.add(inBsvp);
							counter++;
							pst.execute();
						}else {
							System.out.println("There is no such number. Try again.");
						}
						break;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		
}